Tgchat
======
Tgchat provides implementation of the Telegram support for nchat. The main
component is a copy of the official Telegram tdlib - in `ext/td` directory.

Tgchat is enabled by default in nchat builds.
