---
name: Bug report
about: Report a bug by creating a new issue.
labels: bug
assignees: d99kris
---

**Description**:

**How to reproduce it**:

**Environment**:
- Version:
- OS / distro:
